package com.shoppingCart.app.dao;

import com.shoppingCart.app.model.Order;

public interface OrderDao {

	Long save(Order order);

}
